<?php

namespace App\Helpers;


class JWT 
{
     public static $password = 'abC1232321ASD@#!@321wd';

        public static Function validate($token){
            $header = explode('.', $token)[0];
            $payload = explode('.', $token)[1];
            $signature = explode('.', $token)[2];
            
             $signature = JWT::hash($base64UrlHeader . "." . $base64UrlPayload );
            $isValid = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode(JWT::hash($header . "." . $payload))) == $signature ;
             
             if($isValid){
                  return    json_decode(str_replace(['+', '/', '='], ['-', '_', ''], base64_decode($payload)), true);
             }else {
                 return null;
             }
           
        }
        
         public static Function hash($item){
             return hash_hmac('sha256', $item, JWT::$password, true);
         }
   
   public static Function getToken($payload){

                   // Create token header as a JSON string
            $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
            
            // Create token payload as a JSON string
            $payload = json_encode($payload);
            
            // Encode Header to Base64Url String
            $base64UrlHeader = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode           ($header));
            
            // Encode Payload to Base64Url String
            $base64UrlPayload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode           ($payload));
            
            // Create Signature Hash
            $signature = JWT::hash($base64UrlHeader . "." . $base64UrlPayload );
            
            // Encode Signature to Base64Url String
            $base64UrlSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode           ($signature));
            
            // Create JWT
            $jwt = $base64UrlHeader . "." . $base64UrlPayload . "." . $base64UrlSignature;
            
            return $jwt;
   }


}