<?php

namespace App\Http\Controllers;

use App\Helpers\Post;
use Illuminate\Routing\ResponseFactory;
use Illuminate\Http\Request;


use Illuminate\Support\Facades\Artisan;
use PHPUnit\Framework\ExpectationFailedException;
use Symfony\Component\HttpKernel\Exception\HttpException;


class MasterController extends Controller
{

    public function query(Request $request)
    {

	$validateToken = Post::send("authapache/cloud/public/api/authentication/validate", ["token" => $request->post('token')]);

	if($validateToken->status != "done"){return response()->json(["status" => "error"], 401);}

	$url = "dbapache/cloud/public/api/db/query";

        $result = Post::send($url, $request->post());

        return response()->json($result, 200);


    }

  public function vote(Request $request)
    {

	$validateToken = Post::send("authapache/cloud/public/api/authentication/validate", ["token" => $request->post('token')]);

	if($validateToken->status != "done"){return response()->json(["status" => "error"], 401);}

$validateFraudDetection = Post::send("detectionapache/cloud/public/api/detection", ["token" => $request->post('token')]);

	if($validateFraudDetection->status != "done"){return response()->json(["status" => "error"], 401);}


	$url = "dbapache/cloud/public/api/db/query";

	

	$fbid = $request->post('fbid');
	$voterId = $request->post('voterId');
	$candidateId = $request->post('candidateId');

 $result = Post::send($url, ["query" => "INSERT INTO tb_polling (no_induk, id_panitia, id_kandidat) VALUES ('$fbid',$voterId,$candidateId);"]);


	return response()->json(["status" => "done"], 200);


        

    }



}
